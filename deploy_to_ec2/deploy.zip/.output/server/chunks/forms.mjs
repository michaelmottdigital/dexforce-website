import { defineEventHandler } from 'h3';

const forms = defineEventHandler(async (event) => {
  return "forms hello";
});

export { forms as default };
//# sourceMappingURL=forms.mjs.map
