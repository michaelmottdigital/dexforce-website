globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'node:http';
import { Server } from 'node:https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseStatus, setResponseHeader, getRequestHeaders, createError, createApp, createRouter as createRouter$1, toNodeListener, fetchWithEvent, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import defu, { defuFn } from 'defu';
import { hash } from 'ohash';
import { parseURL, withoutBase, joinURL, withQuery, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage, prefixStorage } from 'unstorage';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"envPrefix":"NUXT_","routeRules":{"/__nuxt_error":{"cache":false},"/_nuxt/**":{"headers":{"cache-control":"public, max-age=31536000, immutable"}}}},"public":{"sitename":"DexForce Consulting"},"private":{}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
overrideConfig(_runtimeConfig);
const runtimeConfig = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => runtimeConfig;
deepFreeze(appConfig);
function getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

storage.mount('/assets', assets$1);

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver, shouldInvalidateCache) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry)) {
          useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(key, () => fn(...args), shouldInvalidateCache);
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return key.replace(/[^\dA-Za-z]/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const key = await opts.getKey?.(event);
      if (key) {
        return escapeKey(key);
      }
      const url = event.node.req.originalUrl || event.node.req.url;
      const friendlyName = escapeKey(decodeURI(parseURL(url).pathname)).slice(
        0,
        16
      );
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [opts.integrity, handler]
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const reqProxy = cloneWithProxy(incomingEvent.node.req, { headers: {} });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
      headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString();
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      event.node.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      }
      return proxyRequest(event, target, {
        fetch: $fetch.raw,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.node.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(path, useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const plugins = [
  
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('./error-500.mjs');
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  event.node.res.end(await res.text());
});

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"3c2e-8RkEe4EkeeG748N3d/MJkijlRio\"",
    "mtime": "2023-04-25T23:56:52.688Z",
    "size": 15406,
    "path": "../public/favicon.ico"
  },
  "/_nuxt/blog.4f5da1a5.js": {
    "type": "application/javascript",
    "etag": "\"135-GyZuPLZqoCAqehaZFIaoi57XwCA\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 309,
    "path": "../public/_nuxt/blog.4f5da1a5.js"
  },
  "/_nuxt/coming-soon.8e40f37b.js": {
    "type": "application/javascript",
    "etag": "\"341-AEhNXs/NoI3qEcKOuyllMfYtcso\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 833,
    "path": "../public/_nuxt/coming-soon.8e40f37b.js"
  },
  "/_nuxt/contact-us.eb47ac4c.js": {
    "type": "application/javascript",
    "etag": "\"b5c-f2nSzov4MEimY4NJWebKomXp4qY\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 2908,
    "path": "../public/_nuxt/contact-us.eb47ac4c.js"
  },
  "/_nuxt/design.1346905e.js": {
    "type": "application/javascript",
    "etag": "\"b3-O/7ilSdBujUF8gjBPijlohsXSWM\"",
    "mtime": "2023-05-07T20:38:20.305Z",
    "size": 179,
    "path": "../public/_nuxt/design.1346905e.js"
  },
  "/_nuxt/entry.6a8235a7.js": {
    "type": "application/javascript",
    "etag": "\"3c88d-HmTuXkFHilbJ/W4nPUzm+iOrs18\"",
    "mtime": "2023-05-07T20:38:20.311Z",
    "size": 247949,
    "path": "../public/_nuxt/entry.6a8235a7.js"
  },
  "/_nuxt/entry.767e60ae.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"a9d4-tEglIlRdXUTZcI8EwfV3SFhqTgk\"",
    "mtime": "2023-05-07T20:38:20.305Z",
    "size": 43476,
    "path": "../public/_nuxt/entry.767e60ae.css"
  },
  "/_nuxt/error-404.23f2309d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e2e-ivsbEmi48+s9HDOqtrSdWFvddYQ\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 3630,
    "path": "../public/_nuxt/error-404.23f2309d.css"
  },
  "/_nuxt/error-404.75ef4cca.js": {
    "type": "application/javascript",
    "etag": "\"8d5-TwVF0QSQhUOUHZZ4sl090ryNZMs\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 2261,
    "path": "../public/_nuxt/error-404.75ef4cca.js"
  },
  "/_nuxt/error-500.aa16ed4d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"79e-7j4Tsx89siDo85YoIs0XqsPWmPI\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 1950,
    "path": "../public/_nuxt/error-500.aa16ed4d.css"
  },
  "/_nuxt/error-500.bd77a8b9.js": {
    "type": "application/javascript",
    "etag": "\"759-Sa2VgN6EYZe9rRNIfnUs3HMYUPc\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 1881,
    "path": "../public/_nuxt/error-500.bd77a8b9.js"
  },
  "/_nuxt/error-component.58d2119d.js": {
    "type": "application/javascript",
    "etag": "\"478-IPjeK2q+uVENrylpqEb5gEFc68U\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 1144,
    "path": "../public/_nuxt/error-component.58d2119d.js"
  },
  "/_nuxt/Footer.089c4c8b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3d-xej9DmqqvTjJ5xaJt3vMSkvhSvI\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 61,
    "path": "../public/_nuxt/Footer.089c4c8b.css"
  },
  "/_nuxt/Footer.f77c822b.js": {
    "type": "application/javascript",
    "etag": "\"1830-wsQRv0DVwikKmrZSH1xt8Lkawbs\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 6192,
    "path": "../public/_nuxt/Footer.f77c822b.js"
  },
  "/_nuxt/Header.a3930d50.js": {
    "type": "application/javascript",
    "etag": "\"b35-Fdl2bCYPpDw6dEhjre8OyOrCoSA\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 2869,
    "path": "../public/_nuxt/Header.a3930d50.js"
  },
  "/_nuxt/index.131baf2d.js": {
    "type": "application/javascript",
    "etag": "\"149f-0s65j241uJ9fN7ON9ietN6DV9GM\"",
    "mtime": "2023-05-07T20:38:20.306Z",
    "size": 5279,
    "path": "../public/_nuxt/index.131baf2d.js"
  },
  "/_nuxt/index.17ad4358.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"aa-lKQ4gkn66Qh8Xd2fS1sUlc9tRzw\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 170,
    "path": "../public/_nuxt/index.17ad4358.css"
  },
  "/_nuxt/index.954d0057.js": {
    "type": "application/javascript",
    "etag": "\"88b-+ZzvwnOEr0xdBwpspGZzfoocWnc\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 2187,
    "path": "../public/_nuxt/index.954d0057.js"
  },
  "/_nuxt/index.ad018360.js": {
    "type": "application/javascript",
    "etag": "\"185-yS6/u3B7I/bqRj9Q13uChXLPgUU\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 389,
    "path": "../public/_nuxt/index.ad018360.js"
  },
  "/_nuxt/nonprofit-quickstart.3c309135.js": {
    "type": "application/javascript",
    "etag": "\"b20-3BhkgywsLZg+hFtjse2PzkOgTxI\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 2848,
    "path": "../public/_nuxt/nonprofit-quickstart.3c309135.js"
  },
  "/_nuxt/nonprofit-quickstart.8d134802.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"17-BIxHwh8w6Kx+yMgmzTKeqQXNU3o\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 23,
    "path": "../public/_nuxt/nonprofit-quickstart.8d134802.css"
  },
  "/_nuxt/nuxt-link.5e40a130.js": {
    "type": "application/javascript",
    "etag": "\"10eb-2C/3e048NOk12VtaeiczeyehK9E\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 4331,
    "path": "../public/_nuxt/nuxt-link.5e40a130.js"
  },
  "/_nuxt/on-going-support.d6f12055.js": {
    "type": "application/javascript",
    "etag": "\"946-DBC6hKtEE58BZDcIZfs8PJVYuxQ\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 2374,
    "path": "../public/_nuxt/on-going-support.d6f12055.js"
  },
  "/_nuxt/privacy-policy.932a61b5.js": {
    "type": "application/javascript",
    "etag": "\"232b-OAQfvVXTyxohysIc2vsESvwUs7g\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 9003,
    "path": "../public/_nuxt/privacy-policy.932a61b5.js"
  },
  "/_nuxt/privacy-policy.9fe18b41.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ac-mPL/NxnvUR0DoS7oit1uCUaEa7Q\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 172,
    "path": "../public/_nuxt/privacy-policy.9fe18b41.css"
  },
  "/_nuxt/sample-projects.7d0b6e3c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"21-Nq4TD6vVxABDLBeaKLLB9MM3Mf8\"",
    "mtime": "2023-05-07T20:38:20.301Z",
    "size": 33,
    "path": "../public/_nuxt/sample-projects.7d0b6e3c.css"
  },
  "/_nuxt/sample-projects.b795ca8b.js": {
    "type": "application/javascript",
    "etag": "\"ee0-52OzTFKWa7H3csOFmvUDXlS1ZYw\"",
    "mtime": "2023-05-07T20:38:20.305Z",
    "size": 3808,
    "path": "../public/_nuxt/sample-projects.b795ca8b.js"
  },
  "/_nuxt/SectionHeading.3908d26c.js": {
    "type": "application/javascript",
    "etag": "\"2af-bMLijFMDeZXr0bP2rKd++DnjutE\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 687,
    "path": "../public/_nuxt/SectionHeading.3908d26c.js"
  },
  "/_nuxt/ServiceCard.ed62aa02.js": {
    "type": "application/javascript",
    "etag": "\"100-rQsClWpfxV7lCWRV8tnxywMgEYw\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 256,
    "path": "../public/_nuxt/ServiceCard.ed62aa02.js"
  },
  "/_nuxt/services-old.97523828.js": {
    "type": "application/javascript",
    "etag": "\"88d-tjwbLfFL0n0OGQlRWWGwqGqCyNM\"",
    "mtime": "2023-05-07T20:38:20.299Z",
    "size": 2189,
    "path": "../public/_nuxt/services-old.97523828.js"
  },
  "/_nuxt/terms-and-conditions.4a65bd27.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"100-7HziuQb4sVSVBSNagnMoP4vC0TI\"",
    "mtime": "2023-05-07T20:38:20.304Z",
    "size": 256,
    "path": "../public/_nuxt/terms-and-conditions.4a65bd27.css"
  },
  "/_nuxt/terms-and-conditions.fffb84f0.js": {
    "type": "application/javascript",
    "etag": "\"13cc-BMpPjSfIC0jICV4gZCqroi6/0hU\"",
    "mtime": "2023-05-07T20:38:20.310Z",
    "size": 5068,
    "path": "../public/_nuxt/terms-and-conditions.fffb84f0.js"
  },
  "/img/calendly_1.png": {
    "type": "image/png",
    "etag": "\"1ddb2-Jf2hbAA8O029qM6jRdHVO0V2qrY\"",
    "mtime": "2023-04-25T15:48:55.012Z",
    "size": 122290,
    "path": "../public/img/calendly_1.png"
  },
  "/img/calendly_2.png": {
    "type": "image/png",
    "etag": "\"16fde-mZH5QWSDuKdAF+fLVj4OfF7jpPg\"",
    "mtime": "2023-04-25T15:49:21.908Z",
    "size": 94174,
    "path": "../public/img/calendly_2.png"
  },
  "/img/calendly_3.png": {
    "type": "image/png",
    "etag": "\"2848f-NdnXMnjNbSZOp5fPqzYZAsLUcO8\"",
    "mtime": "2023-04-25T15:49:50.187Z",
    "size": 165007,
    "path": "../public/img/calendly_3.png"
  },
  "/img/facebook.svg": {
    "type": "image/svg+xml",
    "etag": "\"266-otbgUOKu5GpcL8ZYsmNXC9pv6s4\"",
    "mtime": "2023-04-21T17:30:07.737Z",
    "size": 614,
    "path": "../public/img/facebook.svg"
  },
  "/img/facebook_icon.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a1-SzZnWd+EAnlSTrnEPSZVpOTWBXQ\"",
    "mtime": "2023-04-21T17:01:36.800Z",
    "size": 673,
    "path": "../public/img/facebook_icon.svg"
  },
  "/img/floater-gold-dots.png": {
    "type": "image/png",
    "etag": "\"11a-0b90qQEylIwbbEjVT+7k1vlilYQ\"",
    "mtime": "2023-02-02T19:42:20.000Z",
    "size": 282,
    "path": "../public/img/floater-gold-dots.png"
  },
  "/img/home_header_img.jpg": {
    "type": "image/jpeg",
    "etag": "\"3150e-FWvm7tQAgitV5xhWelT0QADCrG0\"",
    "mtime": "2023-02-14T16:13:44.618Z",
    "size": 201998,
    "path": "../public/img/home_header_img.jpg"
  },
  "/img/img-footer-map.png": {
    "type": "image/png",
    "etag": "\"59a-Ajb+XFv+gp79xhxlmBgGxs/nqHs\"",
    "mtime": "2023-02-02T19:42:26.000Z",
    "size": 1434,
    "path": "../public/img/img-footer-map.png"
  },
  "/img/LI-In-Bug.png": {
    "type": "image/png",
    "etag": "\"20b7-6wp+EoTmMdgMMiXA4tbHr5Md5TU\"",
    "mtime": "2023-03-28T18:33:01.162Z",
    "size": 8375,
    "path": "../public/img/LI-In-Bug.png"
  },
  "/img/LI-Logo.png": {
    "type": "image/png",
    "etag": "\"6317-OnsSn3jZMdhQkR1YmieaLmZjhoo\"",
    "mtime": "2023-03-28T18:33:01.141Z",
    "size": 25367,
    "path": "../public/img/LI-Logo.png"
  },
  "/img/linkedin.svg": {
    "type": "image/svg+xml",
    "etag": "\"4cf-M1zmSK02Po1+1aw/y4UWgKaYb9c\"",
    "mtime": "2023-04-21T17:33:53.145Z",
    "size": 1231,
    "path": "../public/img/linkedin.svg"
  },
  "/img/logo-black.png": {
    "type": "image/png",
    "etag": "\"11bb-SfiydZQ1CA2pjEfk69C7sOClObg\"",
    "mtime": "2023-03-02T14:58:56.967Z",
    "size": 4539,
    "path": "../public/img/logo-black.png"
  },
  "/img/logo-white.png": {
    "type": "image/png",
    "etag": "\"15c7-FN75Q3dZSjvvflcxhP5WORPg5HQ\"",
    "mtime": "2023-03-02T15:00:40.804Z",
    "size": 5575,
    "path": "../public/img/logo-white.png"
  },
  "/img/youtube-24px.png": {
    "type": "image/png",
    "etag": "\"2aa-5jCl80/VHzqgcekBUy5p3e8XrYg\"",
    "mtime": "2023-03-28T18:51:42.825Z",
    "size": 682,
    "path": "../public/img/youtube-24px.png"
  },
  "/img/youtube.svg": {
    "type": "image/svg+xml",
    "etag": "\"38a-BRBSmZM2KqcRTJ8dgAhz5AGa0d8\"",
    "mtime": "2023-04-21T20:19:31.321Z",
    "size": 906,
    "path": "../public/img/youtube.svg"
  },
  "/img/youtube_full.svg": {
    "type": "image/svg+xml",
    "etag": "\"13f4-MWTS0TVZhmkem6FqX3/x0yrP9K8\"",
    "mtime": "2023-04-21T17:36:05.656Z",
    "size": 5108,
    "path": "../public/img/youtube_full.svg"
  },
  "/img/sample-projects/BofA_logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"de0-UdNWbkOloAIJdr8eSvp2ZUtY9GQ\"",
    "mtime": "2023-04-13T19:23:54.575Z",
    "size": 3552,
    "path": "../public/img/sample-projects/BofA_logo.svg"
  },
  "/img/sample-projects/Corteva_logo.webp": {
    "type": "image/webp",
    "etag": "\"123e-Twn3jE6/gOO8k3f0gWtwaIAcL5c\"",
    "mtime": "2023-04-13T19:32:38.253Z",
    "size": 4670,
    "path": "../public/img/sample-projects/Corteva_logo.webp"
  },
  "/img/sample-projects/Corteva_logo_original.webp": {
    "type": "image/webp",
    "etag": "\"ed8-SK7zsKQ2kg4Q66aYYzw0vmqI/WU\"",
    "mtime": "2023-04-13T19:21:06.052Z",
    "size": 3800,
    "path": "../public/img/sample-projects/Corteva_logo_original.webp"
  },
  "/img/sample-projects/EBALDC_logo.png": {
    "type": "image/png",
    "etag": "\"6a1a-VuLSMHIeDxf5Od0cAXOMPQKlsIg\"",
    "mtime": "2023-04-13T19:33:48.422Z",
    "size": 27162,
    "path": "../public/img/sample-projects/EBALDC_logo.png"
  },
  "/img/sample-projects/Higher_Call_Ministries_logo.png": {
    "type": "image/png",
    "etag": "\"1ca2-dLWQHa+KQNxpr+TN3khwjlGFVaE\"",
    "mtime": "2023-04-17T17:38:46.916Z",
    "size": 7330,
    "path": "../public/img/sample-projects/Higher_Call_Ministries_logo.png"
  },
  "/img/sample-projects/Mapware_logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"a38-1yjy81j4CYEylwS1m0GIEsGDLD4\"",
    "mtime": "2023-04-13T19:38:49.809Z",
    "size": 2616,
    "path": "../public/img/sample-projects/Mapware_logo.svg"
  },
  "/img/sample-projects/Mastery_Prep_logo.webp": {
    "type": "image/webp",
    "etag": "\"1874-usLOi+CXLLn3zyjFSuROEukqc+k\"",
    "mtime": "2023-04-13T19:27:03.998Z",
    "size": 6260,
    "path": "../public/img/sample-projects/Mastery_Prep_logo.webp"
  },
  "/img/sample-projects/NWHCT_Logo.png": {
    "type": "image/png",
    "etag": "\"a8e8-4eleSPWQ5lfUQb4qrZysRCgwKnM\"",
    "mtime": "2023-04-17T17:39:33.276Z",
    "size": 43240,
    "path": "../public/img/sample-projects/NWHCT_Logo.png"
  },
  "/img/sample-projects/STS_logo.png": {
    "type": "image/png",
    "etag": "\"6e2-1q7ngnFSev801OCAvWoddBK0WZo\"",
    "mtime": "2023-04-13T19:03:08.737Z",
    "size": 1762,
    "path": "../public/img/sample-projects/STS_logo.png"
  },
  "/img/sample-projects/Talent_Stacker_logo.png": {
    "type": "image/png",
    "etag": "\"214b-vgS0OJZtN+dO9rtWZnmLxvG2VaQ\"",
    "mtime": "2023-04-17T17:32:51.254Z",
    "size": 8523,
    "path": "../public/img/sample-projects/Talent_Stacker_logo.png"
  },
  "/img/sample-projects/TE_logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"b6f-O4yf3pV6a3WvSVbCUYQ8sYKS71Y\"",
    "mtime": "2023-04-13T19:10:39.704Z",
    "size": 2927,
    "path": "../public/img/sample-projects/TE_logo.svg"
  },
  "/img/twitter/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-SMXzSvDVRmOE5NlDksCF0J9PRDc\"",
    "mtime": "2023-03-28T18:38:58.063Z",
    "size": 6148,
    "path": "../public/img/twitter/.DS_Store"
  },
  "/img/twitter/rounded-square/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-3y++sUAKzaCQmjLBz2v0kvESHgc\"",
    "mtime": "2023-03-28T18:38:58.102Z",
    "size": 6148,
    "path": "../public/img/twitter/rounded-square/.DS_Store"
  },
  "/img/twitter/rounded-square/rounded-square-white.png": {
    "type": "image/png",
    "etag": "\"1670-BJnUsxZYXBeHFt/n7WjxQKEP6zg\"",
    "mtime": "2023-03-28T18:38:58.191Z",
    "size": 5744,
    "path": "../public/img/twitter/rounded-square/rounded-square-white.png"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - blue.ai": {
    "type": "application/postscript",
    "etag": "\"4031a-fD67FDlOvLwGh2QzCBsqLP6swz4\"",
    "mtime": "2023-03-28T18:38:58.181Z",
    "size": 262938,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - blue.ai"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - blue.eps": {
    "type": "application/postscript",
    "etag": "\"ee5f6-uxBUdIpeGQb1dV7IdlrOVpVRn+o\"",
    "mtime": "2023-03-28T18:38:58.222Z",
    "size": 976374,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - blue.eps"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - blue.png": {
    "type": "image/png",
    "etag": "\"1b4e-BR98aCJl8PZXeFCd4n09F6+w6Rc\"",
    "mtime": "2023-03-28T18:38:58.292Z",
    "size": 6990,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - blue.png"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - blue.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"cdc36-/d4/5zlY5U5I3wJJsrSLDouOKok\"",
    "mtime": "2023-03-28T18:38:58.251Z",
    "size": 842806,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - blue.psd"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - blue.svg": {
    "type": "image/svg+xml",
    "etag": "\"4d8-SyghchmnHnTgIOkk3bOk3d3MBHs\"",
    "mtime": "2023-03-28T18:38:58.322Z",
    "size": 1240,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - blue.svg"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - white.ai": {
    "type": "application/postscript",
    "etag": "\"3d123-I1eGyF3oKwg00fe4EnbND4oz1NM\"",
    "mtime": "2023-03-28T18:38:58.132Z",
    "size": 250147,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - white.ai"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - white.eps": {
    "type": "application/postscript",
    "etag": "\"eca9a-pBZuCGG20i5/H/DkBIG+Pz1gYtg\"",
    "mtime": "2023-03-28T18:38:58.281Z",
    "size": 969370,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - white.eps"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - white.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"b35a8-g6tW8EjFSz/sY9U00Knv42w3WDc\"",
    "mtime": "2023-03-28T18:38:58.151Z",
    "size": 734632,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - white.psd"
  },
  "/img/twitter/rounded-square/Twitter social icons - rounded square - white.svg": {
    "type": "image/svg+xml",
    "etag": "\"468-eua57WOHG8LT9RrmyAvv4WnbDTA\"",
    "mtime": "2023-03-28T18:38:58.082Z",
    "size": 1128,
    "path": "../public/img/twitter/rounded-square/Twitter social icons - rounded square - white.svg"
  },
  "/img/twitter/Twitter social icons - circle/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-3y++sUAKzaCQmjLBz2v0kvESHgc\"",
    "mtime": "2023-03-28T18:38:58.701Z",
    "size": 6148,
    "path": "../public/img/twitter/Twitter social icons - circle/.DS_Store"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.ai": {
    "type": "application/postscript",
    "etag": "\"40ab3-gOxCcO1a7BX7itcWdPZELWGZykU\"",
    "mtime": "2023-03-28T18:38:58.622Z",
    "size": 264883,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.ai"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.eps": {
    "type": "application/postscript",
    "etag": "\"ecbfa-nXuOye4ApHz05/AHo0pbiGWeG+w\"",
    "mtime": "2023-03-28T18:38:58.683Z",
    "size": 969722,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.eps"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.png": {
    "type": "image/png",
    "etag": "\"2508-yv715GHHZHn5fNbfZUfGKCgAs7s\"",
    "mtime": "2023-03-28T18:38:58.842Z",
    "size": 9480,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.png"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"dfc4a-hmTZmR8gdfRnlIlkd4jhekXodug\"",
    "mtime": "2023-03-28T18:38:58.825Z",
    "size": 916554,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.psd"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.svg": {
    "type": "image/svg+xml",
    "etag": "\"474-cfuZso9Y2fujpBzeR2w1Q2OujCc\"",
    "mtime": "2023-03-28T18:38:58.794Z",
    "size": 1140,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - blue.svg"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.ai": {
    "type": "application/postscript",
    "etag": "\"3ecd3-5edMDVO8P3iQDUMqWCFRkOkEGKw\"",
    "mtime": "2023-03-28T18:38:58.772Z",
    "size": 257235,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.ai"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.eps": {
    "type": "application/postscript",
    "etag": "\"eca42-SUZ7VPciY9WsVJ7AOIXtLoUS0zA\"",
    "mtime": "2023-03-28T18:38:58.872Z",
    "size": 969282,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.eps"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.png": {
    "type": "image/png",
    "etag": "\"20ac-/exbAc0wgJVhvK7pHDy7Gs8kzAY\"",
    "mtime": "2023-03-28T18:38:58.722Z",
    "size": 8364,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.png"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"b9dfe-ed5tboyqX+yEO9Hgk7eT+IIAJpo\"",
    "mtime": "2023-03-28T18:38:58.651Z",
    "size": 761342,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.psd"
  },
  "/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.svg": {
    "type": "image/svg+xml",
    "etag": "\"43c-B0ywq0LjqhdbzX94y6+ElWvKgc8\"",
    "mtime": "2023-03-28T18:38:58.746Z",
    "size": 1084,
    "path": "../public/img/twitter/Twitter social icons - circle/Twitter social icons - circle - white.svg"
  },
  "/img/twitter/Twitter social icons - square/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1804-3y++sUAKzaCQmjLBz2v0kvESHgc\"",
    "mtime": "2023-03-28T18:38:58.396Z",
    "size": 6148,
    "path": "../public/img/twitter/Twitter social icons - square/.DS_Store"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.ai": {
    "type": "application/postscript",
    "etag": "\"3fe32-tmSJjm9WHSGYGVucFK2h+YRXh+Y\"",
    "mtime": "2023-03-28T18:38:58.422Z",
    "size": 261682,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.ai"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.eps": {
    "type": "application/postscript",
    "etag": "\"ec4f6-kiwZNd9XWJLZvKOg01yqJ7afZKE\"",
    "mtime": "2023-03-28T18:38:58.372Z",
    "size": 967926,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.eps"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.png": {
    "type": "image/png",
    "etag": "\"b62a-u54zH7jpG6OMh89m9QMb/n7iflI\"",
    "mtime": "2023-03-28T18:38:58.532Z",
    "size": 46634,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.png"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"cf082-eCgV3b53QpJ5FZY4x04lzC1EV0s\"",
    "mtime": "2023-03-28T18:38:58.562Z",
    "size": 848002,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.psd"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.svg": {
    "type": "image/svg+xml",
    "etag": "\"492-7cgxSjzLL0aLdn2ItBOkVJ2SuwY\"",
    "mtime": "2023-03-28T18:38:58.511Z",
    "size": 1170,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - blue.svg"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - white.ai": {
    "type": "application/postscript",
    "etag": "\"3ccc2-gYjW4bAnEUc83iH4KcUnG2rmeSg\"",
    "mtime": "2023-03-28T18:38:58.493Z",
    "size": 249026,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - white.ai"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - white.eps": {
    "type": "application/postscript",
    "etag": "\"e9ede-7d5olptwyHw6YmN1f3ZOG6748kU\"",
    "mtime": "2023-03-28T18:38:58.592Z",
    "size": 958174,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - white.eps"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - white.png": {
    "type": "image/png",
    "etag": "\"1244-9OVX5ZFEhuxzDyYiPiu8s/KEf4Y\"",
    "mtime": "2023-03-28T18:38:58.441Z",
    "size": 4676,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - white.png"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - white.psd": {
    "type": "image/vnd.adobe.photoshop",
    "etag": "\"acefe-b3d5loLJwKlBMelPahXrgJY7Kio\"",
    "mtime": "2023-03-28T18:38:58.349Z",
    "size": 708350,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - white.psd"
  },
  "/img/twitter/Twitter social icons - square/Twitter social icons - square - white.svg": {
    "type": "image/svg+xml",
    "etag": "\"40a-HWX+i8RBWRhYSL6n6D2jQOSCeFc\"",
    "mtime": "2023-03-28T18:38:58.465Z",
    "size": 1034,
    "path": "../public/img/twitter/Twitter social icons - square/Twitter social icons - square - white.svg"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.node.req.method && !METHODS.has(event.node.req.method)) {
    return;
  }
  let id = decodeURIComponent(
    withLeadingSlash(
      withoutTrailingSlash(parseURL(event.node.req.url).pathname)
    )
  );
  let asset;
  const encodingHeader = String(
    event.node.req.headers["accept-encoding"] || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    event.node.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.node.res.removeHeader("cache-control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.node.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  const ifModifiedSinceH = event.node.req.headers["if-modified-since"];
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.node.res.statusCode = 304;
    event.node.res.end();
    return;
  }
  if (asset.type && !event.node.res.getHeader("Content-Type")) {
    event.node.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.node.res.getHeader("ETag")) {
    event.node.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.node.res.getHeader("Last-Modified")) {
    event.node.res.setHeader("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.node.res.getHeader("Content-Encoding")) {
    event.node.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.node.res.getHeader("Content-Length")) {
    event.node.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_9sHoHZ = () => import('./index.mjs');
const _lazy_M3sZ19 = () => import('./forms.post.mjs');
const _lazy_Qvzyhh = () => import('./forms.mjs');
const _lazy_mOJPUF = () => import('./renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/api/books', handler: _lazy_9sHoHZ, lazy: true, middleware: false, method: undefined },
  { route: '/api/forms', handler: _lazy_M3sZ19, lazy: true, middleware: false, method: "post" },
  { route: '/api/forms', handler: _lazy_Qvzyhh, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_mOJPUF, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_mOJPUF, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(
    eventHandler((event) => {
      const envContext = event.node.req.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: $fetch });
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const s = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const i = s.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${i.family === "IPv6" ? `[${i.address}]` : i.address}:${i.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
{
  process.on(
    "unhandledRejection",
    (err) => console.error("[nitro] [dev] [unhandledRejection] " + err)
  );
  process.on(
    "uncaughtException",
    (err) => console.error("[nitro] [dev] [uncaughtException] " + err)
  );
}
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
