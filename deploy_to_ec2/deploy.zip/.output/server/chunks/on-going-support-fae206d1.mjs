import { _ as __nuxt_component_0 } from './Header-f03ced4b.mjs';
import { _ as __nuxt_component_1 } from './SectionHeading-470cc8e2.mjs';
import { _ as __nuxt_component_1$1 } from './Footer-4c04590c.mjs';
import { unref, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { CheckIcon } from '@heroicons/vue/24/outline';
import { e as useHead } from './server.mjs';
import './nuxt-link-5d0b373b.mjs';
import 'ufo';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main = {
  __name: "on-going-support",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      script: [
        {
          async: true,
          src: "https://assets.calendly.com/assets/external/widget.js"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = __nuxt_component_0;
      const _component_SectionHeading = __nuxt_component_1;
      const _component_Footer = __nuxt_component_1$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<div class="flex justify-center mt-10"><div class="w-10/12 md:w-4/5 md:flex"><div>`);
      _push(ssrRenderComponent(_component_SectionHeading, {
        line1: "On Going",
        line2: "Support",
        hideSuperHeading: ""
      }, null, _parent));
      _push(`<ul class="pt-5"><li class="leading-5" data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Perform day to day salesforce administrative tasks </li><li class="mt-5" data-aos="fade-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Keep Salesforce up to date with changes in how your business operates </li><li data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` We will provide strategy, advice and guidance </li><li data-aos="fade-right">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Get access to architects, developers and consultants when needed </li><li data-aos="zoom-in">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Keep salesforce up to date and optimized </li><li data-aos="fade-up">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Understand how new features can help your business </li><li data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Apply best practices for your specific business </li></ul></div><div class="mt-10 md:mt-0 md:ml-20 border border-solid rounded-xl border-gray-300 pb-0 shadow-lg shadow"><div class="mb-8 text-center text-2xl font-bold"> Book a FREE call with the Dexforce team. </div><div class="calendly-inline-widget" data-url="https://calendly.com/michael-dexforce/nonprofit-quick-start-free-consultation?hide_event_type_details=1&amp;hide_gdpr_banner=1" style="${ssrRenderStyle({ "min-width": "320px", "height": "630px" })}"></div></div></div></div>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/services/on-going-support.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=on-going-support-fae206d1.mjs.map
