import { p as publicAssetsURL } from './renderer.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-5d0b373b.mjs';
import { mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { a as _imports_1, b as _imports_2 } from './Footer-98b72eca.mjs';
import { _ as _export_sfc } from './server.mjs';

const _imports_0 = "" + publicAssetsURL("img/logo-black.png");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-center" }, _attrs))}><nav class="flex w-full px-12 px-12 py-5 font-montserrat font-bold bg-gold items-center"><div class="">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/",
    class: "font-oswald font-normal"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0)} class="h-[50px] w-[75px]"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0,
            class: "h-[50px] w-[75px]"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex ml-12">`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/services" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Services`);
      } else {
        return [
          createTextVNode("Services")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/sample-projects",
    class: "ml-5"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Sample Projects`);
      } else {
        return [
          createTextVNode("Sample Projects")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/contact-us",
    class: "ml-5"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Contact Us`);
      } else {
        return [
          createTextVNode("Contact Us")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex ml-auto"> Visit us on social media <a class="pl-2" href="https://www.linkedin.com/company/dexforce/" target="blank"><img${ssrRenderAttr("src", _imports_1)} width="25" height="25"></a><a class="pl-2" href="https://www.youtube.com/channel/UCyuUM5HUyRMZXdgGZ04fC3A" target="blank"><img${ssrRenderAttr("src", _imports_2)} width="25" height="25"></a></div></nav></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Header-59e94c61.mjs.map
