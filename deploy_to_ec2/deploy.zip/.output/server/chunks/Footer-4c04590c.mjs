import { p as publicAssetsURL } from './renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-5d0b373b.mjs';
import { useSSRContext, mergeProps, unref, withCtx, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { EnvelopeIcon, PhoneIcon } from '@heroicons/vue/24/solid';

const _imports_4 = "" + publicAssetsURL("img/logo-black.png");
const _imports_1 = "" + publicAssetsURL("img/facebook.svg");
const _imports_2 = "" + publicAssetsURL("img/linkedin.svg");
const _imports_3 = "" + publicAssetsURL("img/youtube.svg");
const _sfc_main = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-center bg-blue-900 mt-20 py-20" }, _attrs))}><div class="flex w-4/5 justify-between"><div><div class="text-gold font-bold text-xl mt-1">Let&#39;s Talk </div><div class="flex flex-col gap-1 mt-4"><div class="flex text-sm items-center">`);
      _push(ssrRenderComponent(unref(EnvelopeIcon), { class: "h-4 w-4 text-gold inline" }, null, _parent));
      _push(`<span class="ml-3 text-white">support@dexforceconsulting.com</span></div><div class="flex text-sm items-center">`);
      _push(ssrRenderComponent(unref(PhoneIcon), { class: "h-4 w-4 text-gold inline" }, null, _parent));
      _push(`<span class="ml-3 text-white">Schedule a Call</span></div></div></div><div class="flex flex-col gap-1">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/terms-and-conditions",
        class: "text-white"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Terms and conditions`);
          } else {
            return [
              createTextVNode("Terms and conditions")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/privacy-policy",
        class: "text-white"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Privacy Policy`);
          } else {
            return [
              createTextVNode("Privacy Policy")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _, _imports_1 as a, _imports_2 as b, _imports_3 as c, _imports_4 as d };
//# sourceMappingURL=Footer-4c04590c.mjs.map
