import { defineEventHandler, readBody } from 'h3';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';

const REGION = "us-east-2";
const sesClient = new SESClient({
  region: REGION,
  credentials: {
    "secretAccessKey": process.env.AWS_SECRET_ACCESS_KEY,
    "accessKeyId": process.env.AWS_ACCESS_KEY_ID
  }
});
const forms_post = defineEventHandler(async (event) => {
  console.log("**** inside post method*****");
  const data = await readBody(event);
  console.log("data", data);
  const sendEmailCommand = createSendEmailCommand("awsadmin@dexforceconsulting.com", "michael@dexforceconsulting.com", data);
  try {
    return await sesClient.send(sendEmailCommand);
  } catch (e) {
    console.error("Failed to Send Eamil", e);
    return e;
  }
  return data;
});
const createSendEmailCommand = (fromAddress, toAddress, data) => {
  const msgBody = `
    New Lead from Contact Us Form <br/>
    Name: ${data.name} <br/>
    Job Title: ${data.jobTitle} <br/>
    Email: ${data.email} <br/>
    Phone: ${data.phone} <br/>
    Company: ${data.company} <br/>
    Message: ${data.message.replace("\n", "<br/>")}<br/>
  `;
  const msgBodyText = `
    New Lead from Contact Us Form 

    Name: ${data.name} 

    Job Title: ${data.jobTitle} 

    Email: ${data.email} 

    Phone: ${data.phone} 

    Company: ${data.company} 

    Message: ${data.message}  

  `;
  const subject = `New Lead : Contact Us Form => ${data.name} `;
  return new SendEmailCommand({
    Destination: {
      CcAddresses: [],
      ToAddresses: [
        toAddress
      ]
    },
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: msgBody
        },
        Text: {
          Charset: "UTF-8",
          Data: msgBodyText
        }
      },
      Subject: {
        Charset: "UTF-8",
        Data: subject
      }
    },
    Source: fromAddress,
    ReplyToAddresses: []
  });
};

export { forms_post as default };
//# sourceMappingURL=forms.post.mjs.map
