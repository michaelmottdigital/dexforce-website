import { _ as __nuxt_component_0 } from './Header-8c655241.mjs';
import { _ as __nuxt_component_1 } from './SectionHeading-470cc8e2.mjs';
import { _ as __nuxt_component_1$1 } from './Footer-e725476f.mjs';
import { unref, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { CheckIcon } from '@heroicons/vue/24/outline';
import './nuxt-link-5d0b373b.mjs';
import 'ufo';
import './server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'h3';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'maska';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '@heroicons/vue/24/solid';

const _sfc_main = {
  __name: "on-going-support",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = __nuxt_component_0;
      const _component_SectionHeading = __nuxt_component_1;
      const _component_Footer = __nuxt_component_1$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<div class="flex justify-center mt-10"><div class="md:w-4/5 md:flex"><div class="mx-9">`);
      _push(ssrRenderComponent(_component_SectionHeading, {
        line1: "On Going",
        line2: "Support",
        hideSuperHeading: ""
      }, null, _parent));
      _push(`<ul class="pt-5"><li class="leading-5" data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Perform day to day salesforce administrative tasks </li><li class="mt-5" data-aos="fade-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Keep Salesforce up to date with changes in how your business operates </li><li data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` We will provide strategy, advice and guidance </li><li data-aos="fade-right">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Get access to architects, developers and consultants when needed </li><li data-aos="zoom-in">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Keep salesforce up to date and optimized </li><li data-aos="fade-up">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Understand how new features can help your business </li><li data-aos="flip-left">`);
      _push(ssrRenderComponent(unref(CheckIcon), { class: "h-5 w-5 stroke-[4px] mr-2 text-blue-900 inline" }, null, _parent));
      _push(` Apply best practices for your specific business </li></ul></div><div class="mx-2 mt-10 md:mt-0 md:ml-20 pb-0 md:border md:border-solid md:rounded-xl md:border-gray-300 md:shadow-lg md:shadow"><div class="mb-8 px-3 pt-4 text-center text-2xl font-bold"> Book a FREE call with the Dexforce team. </div><div id="calendly-inline-widget" data-auto-load="false" style="${ssrRenderStyle({ "min-width": "320px", "height": "630px" })}"></div></div></div></div>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/services/on-going-support.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=on-going-support-fe040126.mjs.map
