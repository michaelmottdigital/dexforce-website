import { _ as __nuxt_component_0 } from './Header-f03ced4b.mjs';
import { _ as __nuxt_component_1 } from './Footer-4c04590c.mjs';
import { useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import './nuxt-link-5d0b373b.mjs';
import 'ufo';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Header = __nuxt_component_0;
  const _component_Footer = __nuxt_component_1;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Header, null, null, _parent));
  _push(`<div class="flex justify-center" data-v-2716ed14><div class="w-4/5 mt-20 mb-20" data-v-2716ed14><h2 data-v-2716ed14>Web Site Terms and Conditions of Use</h2><h3 data-v-2716ed14>1. Terms</h3><p data-v-2716ed14> By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, applicable laws and regulations and their compliance. If you disagree with any of the stated terms and conditions, you are prohibited from using or accessing this site. The materials contained in this site are secured by relevant copyright and trade mark law. </p><h3 data-v-2716ed14>2. Use License</h3><ol start="1" data-v-2716ed14><li data-v-2716ed14> Permission is allowed to temporarily download one duplicate of the materials (data or programming) on Dexforce Consulting&#39;s site for individual and non-business use only. This is the just a permit of license and not an exchange of title, and under this permit you may not: <ol data-v-2716ed14><li data-v-2716ed14>modify or copy the materials;</li><li data-v-2716ed14>use the materials for any commercial use , or for any public presentation (business or non-business);</li><li data-v-2716ed14>attempt to decompile or rebuild any product or material contained on Dexforce Consulting&#39;s site;</li><li data-v-2716ed14>remove any copyright or other restrictive documentations from the materials;</li><li data-v-2716ed14>transfer the materials to someone else or even &quot;mirror&quot; the materials on other server.</li></ol></li><li data-v-2716ed14> This permit might consequently be terminated if you disregard any of these confinements and may be ended by Dexforce Consulting whenever deemed. After permit termination or when your viewing permit is terminated, you must destroy any downloaded materials in your ownership whether in electronic or printed form. </li></ol><h3 data-v-2716ed14>3. Disclaimer</h3> The materials on Dexforce Consulting&#39;s site are given &quot;as is&quot;. Dexforce Consulting makes no guarantees, communicated or suggested, and thus renounces and nullifies every single other warranties, including without impediment, inferred guarantees or states of merchantability, fitness for a specific reason, or non-encroachment of licensed property or other infringement of rights. Further, Dexforce Consulting does not warrant or make any representations concerning the precision, likely results, or unwavering quality of the utilization of the materials on its Internet site or generally identifying with such materials or on any destinations connected to this website. <h3 data-v-2716ed14>4. Constraints</h3> In no occasion should Dexforce Consulting or its suppliers subject for any harms (counting, without constraint, harms for loss of information or benefit, or because of business interference,) emerging out of the utilization or powerlessness to utilize the materials on Dexforce Consulting&#39;s Internet webpage, regardless of the possibility that Dexforce Consulting or a Dexforce Consulting approved agent has been told orally or in written of the likelihood of such harm. Since a few purviews don&#39;t permit constraints on inferred guarantees, or impediments of obligation for weighty or coincidental harms, these confinements may not make a difference to you. <h3 data-v-2716ed14>5. Amendments and Errata</h3> The materials showing up on Dexforce Consulting&#39;s site could incorporate typographical, or photographic mistakes. Dexforce Consulting does not warrant that any of the materials on its site are exact, finished, or current. Dexforce Consulting may roll out improvements to the materials contained on its site whenever without notification. Dexforce Consulting does not, then again, make any dedication to update the materials. <h3 data-v-2716ed14>6. Links</h3> Dexforce Consulting has not checked on the majority of the websites or links connected to its website and is not in charge of the substance of any such connected webpage. The incorporation of any connection does not infer support by Dexforce Consulting of the site. Utilization of any such connected site is at the user&#39;s own risk. <h3 data-v-2716ed14>7. Site Terms of Use Modifications</h3> Dexforce Consulting may update these terms of utilization for its website whenever without notification. By utilizing this site you are consenting to be bound by the then current form of these Terms and Conditions of Use. <h3 data-v-2716ed14>8. Governing Law</h3> Any case identifying with Dexforce Consulting&#39;s site should be administered by the laws of the country of Florida Dexforce Consulting State without respect to its contention of law provisions. General Terms and Conditions applicable to Use of a Web Site. </div></div>`);
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/terms-and-conditions.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const termsAndConditions = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-2716ed14"]]);

export { termsAndConditions as default };
//# sourceMappingURL=terms-and-conditions-685b10aa.mjs.map
