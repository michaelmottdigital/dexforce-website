const HeaderCarousel_vue_vue_type_style_index_0_lang = ".v-enter-from{opacity:0}.v-enter-to{opacity:1}.v-enter-active{transition:opacity 10s ease}.slide-next-enter-active,.slide-next-leave-active{transition:transform .5s ease-in-out}.slide-next-enter{transform:translate(100%)}.slide-next-leave-to{transform:translate(-100%)}";

const HeaderCarouselStyles_42cfafd5 = [HeaderCarousel_vue_vue_type_style_index_0_lang];

export { HeaderCarouselStyles_42cfafd5 as default };
//# sourceMappingURL=HeaderCarousel-styles.42cfafd5.mjs.map
