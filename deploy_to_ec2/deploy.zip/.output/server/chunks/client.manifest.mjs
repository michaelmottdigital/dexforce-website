const client_manifest = {
  "Footer.css": {
    "resourceType": "style",
    "file": "Footer.089c4c8b.css",
    "src": "Footer.css"
  },
  "_Footer.f77c822b.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "Footer.089c4c8b.css"
    ],
    "file": "Footer.f77c822b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ]
  },
  "Footer.089c4c8b.css": {
    "file": "Footer.089c4c8b.css",
    "resourceType": "style"
  },
  "_Header.a3930d50.js": {
    "resourceType": "script",
    "module": true,
    "file": "Header.a3930d50.js",
    "imports": [
      "_nuxt-link.5e40a130.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_SectionHeading.3908d26c.js": {
    "resourceType": "script",
    "module": true,
    "file": "SectionHeading.3908d26c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ServiceCard.ed62aa02.js": {
    "resourceType": "script",
    "module": true,
    "file": "ServiceCard.ed62aa02.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ad018360.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.ad018360.js",
    "imports": [
      "_Footer.f77c822b.js"
    ]
  },
  "_nuxt-link.5e40a130.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.5e40a130.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.75ef4cca.js",
    "imports": [
      "_nuxt-link.5e40a130.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.bd77a8b9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.767e60ae.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.767e60ae.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:C:/dev/websites/dexforce/.nuxt/error-component.mjs"
    ],
    "file": "entry.6a8235a7.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.767e60ae.css": {
    "file": "entry.767e60ae.css",
    "resourceType": "style"
  },
  "pages/blog.vue": {
    "resourceType": "script",
    "module": true,
    "file": "blog.4f5da1a5.js",
    "imports": [
      "_Header.a3930d50.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog.vue"
  },
  "pages/coming-soon.vue": {
    "resourceType": "script",
    "module": true,
    "file": "coming-soon.8e40f37b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/coming-soon.vue"
  },
  "pages/contact-us.vue": {
    "resourceType": "script",
    "module": true,
    "file": "contact-us.eb47ac4c.js",
    "imports": [
      "_Header.a3930d50.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact-us.vue"
  },
  "pages/design.vue": {
    "resourceType": "script",
    "module": true,
    "file": "design.1346905e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/design.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.17ad4358.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "index.17ad4358.css"
    ],
    "file": "index.131baf2d.js",
    "imports": [
      "_nuxt-link.5e40a130.js",
      "_SectionHeading.3908d26c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.f77c822b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.17ad4358.css": {
    "file": "index.17ad4358.css",
    "resourceType": "style"
  },
  "pages/privacy-policy.css": {
    "resourceType": "style",
    "file": "privacy-policy.9fe18b41.css",
    "src": "pages/privacy-policy.css"
  },
  "pages/privacy-policy.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "privacy-policy.932a61b5.js",
    "imports": [
      "_Header.a3930d50.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-policy.vue"
  },
  "privacy-policy.9fe18b41.css": {
    "file": "privacy-policy.9fe18b41.css",
    "resourceType": "style"
  },
  "pages/sample-projects.css": {
    "resourceType": "style",
    "file": "sample-projects.7d0b6e3c.css",
    "src": "pages/sample-projects.css"
  },
  "pages/sample-projects.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "sample-projects.b795ca8b.js",
    "imports": [
      "_Header.a3930d50.js",
      "_SectionHeading.3908d26c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.f77c822b.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sample-projects.vue"
  },
  "sample-projects.7d0b6e3c.css": {
    "file": "sample-projects.7d0b6e3c.css",
    "resourceType": "style"
  },
  "pages/services-old.vue": {
    "resourceType": "script",
    "module": true,
    "file": "services-old.97523828.js",
    "imports": [
      "_Header.a3930d50.js",
      "_SectionHeading.3908d26c.js",
      "_ServiceCard.ed62aa02.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/services-old.vue"
  },
  "pages/services/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.954d0057.js",
    "imports": [
      "_Header.a3930d50.js",
      "_SectionHeading.3908d26c.js",
      "_ServiceCard.ed62aa02.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/services/index.vue"
  },
  "pages/services/nonprofit-quickstart.css": {
    "resourceType": "style",
    "file": "nonprofit-quickstart.8d134802.css",
    "src": "pages/services/on-going-support.css"
  },
  "pages/services/nonprofit-quickstart.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "nonprofit-quickstart.3c309135.js",
    "imports": [
      "_Header.a3930d50.js",
      "_SectionHeading.3908d26c.js",
      "_Footer.f77c822b.js",
      "_index.ad018360.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/services/nonprofit-quickstart.vue"
  },
  "nonprofit-quickstart.8d134802.css": {
    "file": "nonprofit-quickstart.8d134802.css",
    "resourceType": "style"
  },
  "pages/services/on-going-support.css": {
    "resourceType": "style",
    "file": "nonprofit-quickstart.8d134802.css",
    "src": "pages/services/on-going-support.css"
  },
  "pages/services/on-going-support.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "on-going-support.d6f12055.js",
    "imports": [
      "_Header.a3930d50.js",
      "_SectionHeading.3908d26c.js",
      "_Footer.f77c822b.js",
      "_index.ad018360.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/services/on-going-support.vue"
  },
  "pages/terms-and-conditions.css": {
    "resourceType": "style",
    "file": "terms-and-conditions.4a65bd27.css",
    "src": "pages/terms-and-conditions.css"
  },
  "pages/terms-and-conditions.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "terms-and-conditions.fffb84f0.js",
    "imports": [
      "_Header.a3930d50.js",
      "_Footer.f77c822b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.5e40a130.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/terms-and-conditions.vue"
  },
  "terms-and-conditions.4a65bd27.css": {
    "file": "terms-and-conditions.4a65bd27.css",
    "resourceType": "style"
  },
  "virtual:nuxt:C:/dev/websites/dexforce/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.58d2119d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/dev/websites/dexforce/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
