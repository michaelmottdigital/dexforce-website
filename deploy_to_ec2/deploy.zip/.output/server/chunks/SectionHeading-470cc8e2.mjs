import { ssrRenderStyle, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { useSSRContext } from 'vue';

const _sfc_main = {
  __name: "SectionHeading",
  __ssrInlineRender: true,
  props: {
    superHeading: String,
    line1: String,
    line2: String,
    inHomeHeader: { type: Boolean, default: false },
    hideSuperHeading: { type: Boolean, default: false }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="flex items-center"><hr class="w-12 border-gold border-1 mr-3" style="${ssrRenderStyle(__props.hideSuperHeading == false ? null : { display: "none" })}"><span class="text-lg" style="${ssrRenderStyle(__props.hideSuperHeading == false ? null : { display: "none" })}">${ssrInterpolate(__props.superHeading)}</span></div><h2><div class="text-gold mt-2">${ssrInterpolate(__props.line1)}</div><div class="${ssrRenderClass([[__props.inHomeHeader ? "text-white" : "text-blue-900"], "mt-2"])}">${ssrInterpolate(__props.line2)}</div></h2><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SectionHeading.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=SectionHeading-470cc8e2.mjs.map
