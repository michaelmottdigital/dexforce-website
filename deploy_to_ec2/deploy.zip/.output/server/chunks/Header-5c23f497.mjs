import { _ as __nuxt_component_0$1 } from './nuxt-link-5d0b373b.mjs';
import { useSSRContext, ref, withCtx, createVNode, createTextVNode, unref } from 'vue';
import { ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { d as _imports_4, a as _imports_1, b as _imports_2, c as _imports_3 } from './Footer-6f8e57f4.mjs';

const _sfc_main = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    var isMobileMenuVisible = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<!--[--><div class="flex justify-center hidden md:flex"><nav class="md:flex w-full px-12 py-4 font-montserrat font-bold bg-gold items-center"><div class="">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "font-oswald font-normal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_4)} class="h-[50px] w-[75px]"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_4,
                class: "h-[50px] w-[75px]"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex ml-12">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Home`);
          } else {
            return [
              createTextVNode("Home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/services",
        class: "ml-5"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Services`);
          } else {
            return [
              createTextVNode("Services")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/sample-projects",
        class: "ml-5"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sample Projects`);
          } else {
            return [
              createTextVNode("Sample Projects")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/contact-us",
        class: "ml-5"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Contact Us`);
          } else {
            return [
              createTextVNode("Contact Us")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex ml-auto"> Visit us on social media <a class="pl-2" href="https://www.facebook.com/DexForceConsulting" target="blank"><img${ssrRenderAttr("src", _imports_1)}></a><a class="pl-2" href="https://www.linkedin.com/company/dexforce/" target="blank"><img${ssrRenderAttr("src", _imports_2)}></a><a class="pl-3" href="https://www.youtube.com/channel/UCyuUM5HUyRMZXdgGZ04fC3A" target="blank"><img${ssrRenderAttr("src", _imports_3)}></a></div></nav></div><div class="md:hidden bg-gold p-4"><div class="flex items-center justify-between"><button class="outline-none mobile-menu-button"><svg class="w-6 h-6 text-gray-500" x-show="!showMenu" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 6h16M4 12h16M4 18h16"></path></svg></button><div class="">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "font-oswald font-normal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_4)} class="h-[50px] w-[75px]"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_4,
                class: "h-[50px] w-[75px]"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex"><a class="pl-2" href="https://www.facebook.com/DexForceConsulting" target="blank"><img${ssrRenderAttr("src", _imports_1)}></a><a class="pl-2" href="https://www.linkedin.com/company/dexforce/" target="blank"><img${ssrRenderAttr("src", _imports_2)}></a><a class="pl-3" href="https://www.youtube.com/channel/UCyuUM5HUyRMZXdgGZ04fC3A" target="blank"><img${ssrRenderAttr("src", _imports_3)}></a></div></div></div><div class="flex bg-blue-900 justify-center py-5"><a href="https://npchallenge.dexforceconsulting.com" class="font-bold hover:underline text-white text-lg"> Sign up for the free 5 day nonprofit challenge </a></div>`);
      if (unref(isMobileMenuVisible)) {
        _push(`<div class="flex flex-col mobile-menu absolute bg-gold gap-1 p-4">`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Home`);
            } else {
              return [
                createTextVNode("Home")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/services" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Services`);
            } else {
              return [
                createTextVNode("Services")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/sample-projects" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Sample Projects`);
            } else {
              return [
                createTextVNode("Sample Projects")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/contact-us" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Contact Us`);
            } else {
              return [
                createTextVNode("Contact Us")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Header-5c23f497.mjs.map
