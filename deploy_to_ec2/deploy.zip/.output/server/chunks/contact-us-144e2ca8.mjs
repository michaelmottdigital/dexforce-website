import { _ as __nuxt_component_0 } from './Header-becf0119.mjs';
import { _ as __nuxt_component_1 } from './Footer-851a0772.mjs';
import { ref, unref, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './nuxt-link-5d0b373b.mjs';
import './server.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import '@heroicons/vue/24/solid';

const _sfc_main = {
  __name: "contact-us",
  __ssrInlineRender: true,
  setup(__props) {
    let formSubmitSuccess = ref(false);
    const formData = ref({
      name: "",
      jobTitle: "",
      email: "",
      phone: "",
      company: "",
      message: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = __nuxt_component_0;
      const _component_Footer = __nuxt_component_1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<div class="flex justify-center"><div class="w-4/5 border-solid"><div class="flex-col">`);
      if (!unref(formSubmitSuccess)) {
        _push(`<div class="text-center text-2xl p-10">How can we help?</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div>`);
      if (!unref(formSubmitSuccess)) {
        _push(`<form class="flex flex-col gap-4 m-auto w-1/2"><div class="flex flex-col gap-1"><label for="full-name" class="">Name</label><input type="text" name="full-name"${ssrRenderAttr("value", formData.value.name)} placeholder="Enter your full name" required></div><div class="flex flex-col gap-1"><label for="company">Company</label><input type="text" name="company"${ssrRenderAttr("value", formData.value.company)} placeholder="Enter your company name"></div><div class="flex flex-col gap-1"><label for="email">Email Address</label><input type="email" name="email"${ssrRenderAttr("value", formData.value.email)} placeholder="Enter your email"></div><div class="flex flex-col gap-1"><label for="phone">Phone</label><input type="phone" name="phone"${ssrRenderAttr("value", formData.value.phone)} placeholder="Enter your phone #"></div><div class="flex flex-col gap-1"><label for="job-title">Job Title</label><input type="text" name="job-title"${ssrRenderAttr("value", formData.value.jobTitle)} placeholder="Enter your title"></div><div class="flex flex-col gap-1"><label for="message">How can we help you?</label><textarea textarea rows="5" name="message" placeholder="Send us a message">${ssrInterpolate(formData.value.message)}</textarea></div><div><input type="submit" value="Send" class="border-1 bg-blue-900 p-5 text-white rounded-lg font-bold"></div></form>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(formSubmitSuccess)) {
        _push(`<div class="text-center m-[10rem]"><h3>Thank you for submitting your request. We&#39;ll get back to you shortly.</h3></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/contact-us.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=contact-us-144e2ca8.mjs.map
