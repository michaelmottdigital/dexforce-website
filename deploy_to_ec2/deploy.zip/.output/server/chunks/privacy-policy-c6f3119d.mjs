import { _ as __nuxt_component_0 } from './Header-f03ced4b.mjs';
import { _ as __nuxt_component_1 } from './Footer-4c04590c.mjs';
import { useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import './nuxt-link-5d0b373b.mjs';
import 'ufo';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Header = __nuxt_component_0;
  const _component_Footer = __nuxt_component_1;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Header, null, null, _parent));
  _push(`<div id="privacy-policy" class="flex justify-center" data-v-5fde568a><div class="w-4/5 mt-20 mb-20" data-v-5fde568a><h2 data-v-5fde568a>Privacy Policy</h2><p data-v-5fde568a> At Dexforce Consulting, accessible from http://www.dexforceconsulting.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Dexforce Consulting and how we use it. </p><p data-v-5fde568a> If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us. </p> This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in Dexforce Consulting. This policy is not applicable to any information collected offline or via channels other than this website. <h2 data-v-5fde568a> Consent </h2><p data-v-5fde568a> By using our website, you hereby consent to our Privacy Policy and agree to its terms. </p><h3 data-v-5fde568a>Information we collect</h3><p data-v-5fde568a> The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information. </p><p data-v-5fde568a> If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide. </p><p data-v-5fde568a> When you register for an Account, we may ask for your contact information, including items such as name, company name, address, email address, and telephone number. </p><h3 data-v-5fde568a> How we use your information </h3><p data-v-5fde568a> We use the information we collect in various ways, including to: </p><ul data-v-5fde568a><li data-v-5fde568a>Provide, operate, and maintain our website </li><li data-v-5fde568a>Improve, personalize, and expand our website </li><li data-v-5fde568a>Understand and analyze how you use our website</li><li data-v-5fde568a>Develop new products, services, features, and functionality </li><li data-v-5fde568a>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes </li><li data-v-5fde568a>Send you emails</li><li data-v-5fde568a>Find and prevent fraud</li><li data-v-5fde568a>Log Files</li><li data-v-5fde568a>Dexforce Consulting follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services&#39; analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users&#39; movement on the website, and gathering demographic information.<br data-v-5fde568a></li></ul><h3 data-v-5fde568a>Cookies and Web Beacons</h3><p data-v-5fde568a> Like any other website, Dexforce Consulting uses &quot;cookies&quot;. These cookies are used to store information including visitors&#39; preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users&#39; experience by customizing our web page content based on visitors&#39; browser type and/or other information. </p><h3 data-v-5fde568a>Advertising Partners Privacy Policies</h3><p data-v-5fde568a> You may consult this list to find the Privacy Policy for each of the advertising partners of Dexforce Consulting. </p><p data-v-5fde568a> Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on Dexforce Consulting, which are sent directly to users&#39; browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit. </p> Note that Dexforce Consulting has no access to or control over these cookies that are used by third-party advertisers. <h3 data-v-5fde568a>Third Party Privacy Policies</h3><p data-v-5fde568a> Dexforce Consulting&#39;s Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options. </p><p data-v-5fde568a> You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers&#39; respective websites. </p><h3 data-v-5fde568a>CCPA Privacy Rights (Do Not Sell My Personal Information)</h3><p data-v-5fde568a> Under the CCPA, among other rights, California consumers have the right to: </p><p data-v-5fde568a> Request that a business that collects a consumer&#39;s personal data disclose the categories and specific pieces of personal data that a business has collected about consumers. </p><p data-v-5fde568a> Request that a business delete any personal data about the consumer that a business has collected. </p><p data-v-5fde568a> Request that a business that sells a consumer&#39;s personal data, not sell the consumer&#39;s personal data. </p><p data-v-5fde568a> If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us. </p><h3 data-v-5fde568a>GDPR Data Protection Rights</h3><p data-v-5fde568a> We would like to make sure you are fully aware of all of your data protection rights. Every user is entitled to the following: </p><p data-v-5fde568a> The right to access \u2013 You have the right to request copies of your personal data. We may charge you a small fee for this service. </p><p data-v-5fde568a> The right to rectification \u2013 You have the right to request that we correct any information you believe is inaccurate. You also have the right to request that we complete the information you believe is incomplete. </p><p data-v-5fde568a> The right to erasure \u2013 You have the right to request that we erase your personal data, under certain conditions. </p><p data-v-5fde568a> The right to restrict processing \u2013 You have the right to request that we restrict the processing of your personal data, under certain conditions. </p><p data-v-5fde568a> The right to object to processing \u2013 You have the right to object to our processing of your personal data, under certain conditions. </p><p data-v-5fde568a> The right to data portability \u2013 You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions. </p><p data-v-5fde568a> If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us. </p><h3 data-v-5fde568a>Children&#39;s Information</h3><p data-v-5fde568a> Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity. </p><p data-v-5fde568a> Dexforce Consulting does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records. </p><h3 data-v-5fde568a>Changes to This Privacy Policy</h3><p data-v-5fde568a> We may update our Privacy Policy from time to time. Thus, we advise you to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately, after they are posted on this page. </p><p data-v-5fde568a> Our Privacy Policy was created with the help of the Privacy Policy Generator. </p><h3 data-v-5fde568a>Contact Us</h3><p data-v-5fde568a> If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us. </p></div></div>`);
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/privacy-policy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const privacyPolicy = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-5fde568a"]]);

export { privacyPolicy as default };
//# sourceMappingURL=privacy-policy-c6f3119d.mjs.map
