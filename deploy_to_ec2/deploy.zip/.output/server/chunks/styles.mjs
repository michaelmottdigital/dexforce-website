const interopDefault = r => r.default || r || [];
const styles = {
  "pages/privacy-policy.vue": () => import('./privacy-policy-styles.6a9abc07.mjs').then(interopDefault),
  "pages/sample-projects.vue": () => import('./sample-projects-styles.5b2a90b3.mjs').then(interopDefault),
  "pages/services/nonprofit-quickstart.vue": () => import('./nonprofit-quickstart-styles.c14e41fa.mjs').then(interopDefault),
  "pages/services/on-going-support.vue": () => import('./on-going-support-styles.23040e70.mjs').then(interopDefault),
  "pages/terms-and-conditions.vue": () => import('./terms-and-conditions-styles.364f2c35.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./error-404-styles.a5c3f351.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./error-500-styles.6b5b5ff2.mjs').then(interopDefault),
  "components/HeaderCarousel.vue": () => import('./HeaderCarousel-styles.1187c0a6.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
