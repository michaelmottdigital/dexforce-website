import { p as publicAssetsURL } from './renderer.mjs';
import { _ as __nuxt_component_0$2 } from './nuxt-link-5d0b373b.mjs';
import { _ as __nuxt_component_1$1 } from './SectionHeading-470cc8e2.mjs';
import { useSSRContext, withCtx, createTextVNode, ref, onUnmounted, mergeProps, unref, toDisplayString } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as __nuxt_component_2, a as _imports_1, b as _imports_2 } from './Footer-98b72eca.mjs';
import { _ as _export_sfc } from './server.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main$3 = {
  __name: "HeaderCarouselItem",
  __ssrInlineRender: true,
  props: {
    superHeading: String,
    line1: String,
    line2: String,
    buttonText: String,
    buttonUrl: String,
    message: String
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SectionHeading = __nuxt_component_1$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "carousel-item" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_SectionHeading, {
        superHeading: props.superHeading,
        line1: props.line1,
        line2: props.line2,
        inHomeHeader: ""
      }, null, _parent));
      _push(`<p class="mt-6 text-lg">${ssrInterpolate(props.message)}</p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: props.buttonUrl,
        class: "w-[11rem] block bg-gold rounded-3xl mt-10 py-3 px-10 text-black text-black font-bold hover:-translate-y-1 hover:scale-110 duration-300"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(props.buttonText)}`);
          } else {
            return [
              createTextVNode(toDisplayString(props.buttonText), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeaderCarouselItem.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "HeaderCarousel",
  __ssrInlineRender: true,
  setup(__props) {
    const items = [
      {
        id: "0",
        superHeading: "We want you to succeed",
        line1: "On Going",
        line2: "Salesforce Support",
        buttonText: "Learn More",
        buttonUrl: "/services/on-going-support",
        message: "Dexforce Managed Services is a flexible and economic solution to realize your investment in Salesforce without the need to hire full time employees."
      },
      {
        id: "1",
        superHeading: "Helping those who help others",
        line1: "Quick Start",
        line2: "for Nonprofits",
        buttonText: "Learn More",
        buttonUrl: "/services/nonprofit-quickstart",
        message: "A Quick start package to help you get up and running with Salesforce for Nonprofits."
      }
    ];
    var visibleItem = ref(0);
    var interval;
    ref(0);
    onUnmounted(() => {
      clearInterval(interval);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderCarouselItem = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        name: "list",
        id: "wrapper1"
      }, _attrs))}>`);
      ssrRenderList(items, (item, index2) => {
        if (item.id == unref(visibleItem)) {
          _push(ssrRenderComponent(_component_HeaderCarouselItem, {
            superHeading: item.superHeading,
            line1: item.line1,
            line2: item.line2,
            buttonText: item.buttonText,
            buttonUrl: item.buttonUrl,
            message: item.message
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
      });
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeaderCarousel.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _imports_0 = "" + publicAssetsURL("img/logo-white.png");
const _sfc_main$1 = {
  __name: "HeaderHome",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_HeaderCarousel = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-screen" style="${ssrRenderStyle({ "background-image": "url('img/home_header_img.jpg')" })}"><div id="blue-panel" class="absolute bg-blue-900 h-screen border-solid rounded-br-[12rem] w-[44rem]"></div><div class="flex flex-col w-full"><div class="flex justify-center z-10"><div class="w-4/5 py-10"><img${ssrRenderAttr("src", _imports_0)} class="h-[75px] w-[110px]"></div></div><div class="flex justify-center z-10"><nav class="flex w-4/5 mt-15 justify-between px-20 py-7 font-montserrat font-bold bg-gold"><div class="flex">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/services" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Services`);
          } else {
            return [
              createTextVNode("Services")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/sample-projects",
        class: "ml-5"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sample Projects`);
          } else {
            return [
              createTextVNode("Sample Projects")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/contact-us",
        class: "ml-5"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Contact Us`);
          } else {
            return [
              createTextVNode("Contact Us")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex"> Visit us on social media <a class="pl-2" href="https://www.linkedin.com/company/dexforce/" target="blank"><img${ssrRenderAttr("src", _imports_1)} width="25" height="25"></a><a class="pl-2" href="https://www.youtube.com/channel/UCyuUM5HUyRMZXdgGZ04fC3A" target="blank"><img${ssrRenderAttr("src", _imports_2)} width="25" height="25"></a></div></nav></div><div class="flex text-white z-[999] justify-center py-20"><div class="flex w-4/5"><div class="w-5/12">`);
      _push(ssrRenderComponent(_component_HeaderCarousel, null, null, _parent));
      _push(`</div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeaderHome.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_HeaderHome = __nuxt_component_0;
  const _component_Footer = __nuxt_component_2;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_HeaderHome, null, null, _parent));
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-1e4d7ce9.mjs.map
