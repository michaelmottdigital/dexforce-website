const onGoingSupport_vue_vue_type_style_index_0_lang = "li{margin-top:1.25rem}";

const onGoingSupportStyles_23040e70 = [onGoingSupport_vue_vue_type_style_index_0_lang];

export { onGoingSupportStyles_23040e70 as default };
//# sourceMappingURL=on-going-support-styles.23040e70.mjs.map
