const termsAndConditions_vue_vue_type_style_index_0_scoped_2716ed14_lang = "p[data-v-2716ed14]{margin-bottom:1em}li[data-v-2716ed14]{list-style-type:circle}li[data-v-2716ed14],ol[data-v-2716ed14]{margin-left:1em}ol[data-v-2716ed14]{list-style-type:decimal}h2[data-v-2716ed14],h3[data-v-2716ed14]{margin-bottom:.5em;margin-top:.7em}";

const termsAndConditionsStyles_364f2c35 = [termsAndConditions_vue_vue_type_style_index_0_scoped_2716ed14_lang];

export { termsAndConditionsStyles_364f2c35 as default };
//# sourceMappingURL=terms-and-conditions-styles.364f2c35.mjs.map
