import { p as publicAssetsURL } from './renderer.mjs';
import { _ as __nuxt_component_0 } from './Header-becf0119.mjs';
import { _ as __nuxt_component_1 } from './SectionHeading-470cc8e2.mjs';
import { withCtx, createVNode, createTextVNode, useSSRContext, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrRenderAttrs, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import { _ as __nuxt_component_1$1 } from './Footer-851a0772.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './nuxt-link-5d0b373b.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import '@heroicons/vue/24/solid';

const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "align-middle" }, _attrs))}><div class="bg-white max-w-sm rounded-lg shadow-2xl p-10 text-center flex flex-col gap-14"><div class="">`);
  ssrRenderSlot(_ctx.$slots, "logo", {}, null, _push, _parent);
  _push(`</div>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SampleProjectCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("img/sample-projects/NWHCT_Logo.png");
const _imports_1 = "" + publicAssetsURL("img/sample-projects/Higher_Call_Ministries_logo.png");
const _imports_2 = "" + publicAssetsURL("img/sample-projects/Talent_Stacker_logo.png");
const _imports_3 = "" + publicAssetsURL("img/sample-projects/EBALDC_logo.png");
const _imports_4 = "" + publicAssetsURL("img/sample-projects/Corteva_logo.webp");
const _imports_5 = "" + publicAssetsURL("img/sample-projects/BofA_logo.svg");
const _imports_6 = "" + publicAssetsURL("img/sample-projects/TE_logo.svg");
const _imports_7 = "" + publicAssetsURL("img/sample-projects/STS_logo.png");
const _imports_8 = "" + publicAssetsURL("img/sample-projects/Mastery_Prep_logo.webp");
const _imports_9 = "" + publicAssetsURL("img/sample-projects/Mapware_logo.svg");
const _sfc_main = {
  __name: "sample-projects",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = __nuxt_component_0;
      const _component_SectionHeading = __nuxt_component_1;
      const _component_SampleProjectCard = __nuxt_component_2;
      const _component_Footer = __nuxt_component_1$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<div class="flex justify-center mt-10"><div class="w-4/5 bl-blue-100">`);
      _push(ssrRenderComponent(_component_SectionHeading, {
        line1: "Sample",
        line2: "Projects",
        hideSuperHeading: ""
      }, null, _parent));
      _push(`<div class="client-list mt-5 leading-loose flex flex-wrap gap-10">`);
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-[15rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "w-[15rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Non Profit Quick Start `);
          } else {
            return [
              createTextVNode(" Non Profit Quick Start ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "flip-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_1)} class="w-[10rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_1,
                class: "w-[10rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Non Profit Quick Start `);
          } else {
            return [
              createTextVNode(" Non Profit Quick Start ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-down-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_2)} class="w-[15rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_2,
                class: "w-[15rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Non Profit Quick Start `);
          } else {
            return [
              createTextVNode(" Non Profit Quick Start ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_3)} class="w-[15rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_3,
                class: "w-[15rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Non Profit Quick Start `);
          } else {
            return [
              createTextVNode(" Non Profit Quick Start ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-left" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_4)} class="w-[8rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_4,
                class: "w-[8rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Expanded the use of Salesforce to the sales team. Integrated Salesforce with industry seed database and several other internal custom developed systems. `);
          } else {
            return [
              createTextVNode(" Expanded the use of Salesforce to the sales team. Integrated Salesforce with industry seed database and several other internal custom developed systems. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-down-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_5)} class="w-[18rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_5,
                class: "w-[18rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Helped integrate Salesforce with a third party encryption technology. `);
          } else {
            return [
              createTextVNode(" Helped integrate Salesforce with a third party encryption technology. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "flip-up" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_6)} class="w-[8rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_6,
                class: "w-[8rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Migrated 3,000,000 customer inquiries from RightNow to Salesforce. `);
          } else {
            return [
              createTextVNode(" Migrated 3,000,000 customer inquiries from RightNow to Salesforce. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "fade-right" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_7)} class="w-[12rem] mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_7,
                class: "w-[12rem] mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Transition from Marketo to Marketing Cloud. Salesforce data cleanup and de-duplication. Re-aligned Salesforce with the sales and marketing processes and improved collaboration between teams. `);
          } else {
            return [
              createTextVNode(" Transition from Marketo to Marketing Cloud. Salesforce data cleanup and de-duplication. Re-aligned Salesforce with the sales and marketing processes and improved collaboration between teams. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "zoom-in" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_8)} class="mx-auto"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_8,
                class: "mx-auto"
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Initial implementation of Pardot. Integrated a third party printing vendor with Salesforce so sales orders can automatically be sent and then drop-shipped to the customer. `);
          } else {
            return [
              createTextVNode(" Initial implementation of Pardot. Integrated a third party printing vendor with Salesforce so sales orders can automatically be sent and then drop-shipped to the customer. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_SampleProjectCard, { "data-aos": "zoom-out-up" }, {
        logo: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_9)} class="w-[12rem] mx-auto" style="${ssrRenderStyle({ "background-color": "rgb(44, 61, 80)", "padding": "1rem" })}"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_9,
                class: "w-[12rem] mx-auto",
                style: { "background-color": "rgb(44, 61, 80)", "padding": "1rem" }
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Service Cloud quick start. `);
          } else {
            return [
              createTextVNode(" Service Cloud quick start. ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sample-projects.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sample-projects-fe7a4ca6.mjs.map
