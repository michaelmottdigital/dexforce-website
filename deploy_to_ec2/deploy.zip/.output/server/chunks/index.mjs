import { defineEventHandler } from 'h3';

const index = defineEventHandler(async (event) => {
  return "hello from books";
});

export { index as default };
//# sourceMappingURL=index.mjs.map
