const privacyPolicy_vue_vue_type_style_index_0_lang = "p{margin-bottom:1em}li{list-style-type:circle;margin-left:1em}h2,h3{margin-bottom:.5em;margin-top:.7em}";

const privacyPolicyStyles_a20d8fb3 = [privacyPolicy_vue_vue_type_style_index_0_lang];

export { privacyPolicyStyles_a20d8fb3 as default };
//# sourceMappingURL=privacy-policy-styles.a20d8fb3.mjs.map
