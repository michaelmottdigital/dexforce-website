const HeaderCarousel_vue_vue_type_style_index_0_lang = ".list-enter-active,.list-leave-active{opacity:0;transform:translateX(300px);transition:all .5s ease}.list-enter-from,.list-leave-to{opacity:0;transform:translateX(-300px)}";

const HeaderCarouselStyles_1187c0a6 = [HeaderCarousel_vue_vue_type_style_index_0_lang];

export { HeaderCarouselStyles_1187c0a6 as default };
//# sourceMappingURL=HeaderCarousel-styles.1187c0a6.mjs.map
