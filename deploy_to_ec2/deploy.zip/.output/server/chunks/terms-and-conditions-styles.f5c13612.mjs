const termsAndConditions_vue_vue_type_style_index_0_lang = "p{margin-bottom:1em}li{list-style-type:circle}li,ol{margin-left:1em}ol{list-style-type:decimal}h2,h3{margin-bottom:.5em;margin-top:.7em}";

const termsAndConditionsStyles_f5c13612 = [termsAndConditions_vue_vue_type_style_index_0_lang];

export { termsAndConditionsStyles_f5c13612 as default };
//# sourceMappingURL=terms-and-conditions-styles.f5c13612.mjs.map
