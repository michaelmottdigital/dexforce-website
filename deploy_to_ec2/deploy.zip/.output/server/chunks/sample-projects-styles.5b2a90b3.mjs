const sampleProjects_vue_vue_type_style_index_0_lang = ".client-list>div{margin-top:2em}";

const sampleProjectsStyles_5b2a90b3 = [sampleProjects_vue_vue_type_style_index_0_lang];

export { sampleProjectsStyles_5b2a90b3 as default };
//# sourceMappingURL=sample-projects-styles.5b2a90b3.mjs.map
