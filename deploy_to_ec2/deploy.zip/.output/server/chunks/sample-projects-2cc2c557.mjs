import { p as publicAssetsURL } from './renderer.mjs';
import { _ as __nuxt_component_0 } from './Header-59e94c61.mjs';
import { _ as __nuxt_component_1 } from './SectionHeading-470cc8e2.mjs';
import { _ as __nuxt_component_2 } from './Footer-98b72eca.mjs';
import { useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import './nuxt-link-5d0b373b.mjs';
import './server.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import '@heroicons/vue/24/solid';

const _imports_0 = "" + publicAssetsURL("img/sample-projects/EBALDC_logo.png");
const _imports_1 = "" + publicAssetsURL("img/sample-projects/Mapware_logo.svg");
const _imports_2 = "" + publicAssetsURL("img/sample-projects/TE_logo.svg");
const _imports_3 = "" + publicAssetsURL("img/sample-projects/Corteva_logo.webp");
const _imports_4 = "" + publicAssetsURL("img/sample-projects/BofA_logo.svg");
const _imports_5 = "" + publicAssetsURL("img/sample-projects/STS_logo.png");
const _imports_6 = "" + publicAssetsURL("img/sample-projects/Mastery_Prep_logo.webp");
const _sfc_main = {
  __name: "sample-projects",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = __nuxt_component_0;
      const _component_SectionHeading = __nuxt_component_1;
      const _component_Footer = __nuxt_component_2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<div class="flex justify-center mt-10"><div class="w-4/5 bl-blue-100">`);
      _push(ssrRenderComponent(_component_SectionHeading, {
        line1: "Sample",
        line2: "Projects",
        hideSuperHeading: ""
      }, null, _parent));
      _push(`<div class="client-list mt-5 leading-loose"><div><img${ssrRenderAttr("src", _imports_0)}> Non Profit Quick Start </div><div><img${ssrRenderAttr("src", _imports_1)} class="w-[15rem]" style="${ssrRenderStyle({ "background-color": "rgb(44, 61, 80)", "padding": "1rem" })}"> Service Cloud quick start. </div><div><img${ssrRenderAttr("src", _imports_2)}> Migrated 3,000,000 customer inquiries from RightNow to Salesforce. </div><div><img${ssrRenderAttr("src", _imports_3)}> Expanded the use of Salesforce to the sales team. Integrated Salesforce with industry seed database and several other internal custom developed systems. </div><div><img${ssrRenderAttr("src", _imports_4)} class="w-[20rem]"> Helped integrate Salesforce with a third party encryption technology based out of Israel. @Bank of America </div><div><img${ssrRenderAttr("src", _imports_5)}> Transition from Marketo to Marketing Cloud. Data cleanup and de-duplication. Page layout and field detail changes to increase consistency across leads, contacts and accounts. Increased collaboration between marketing and sales teams. A digital transformation initiative across sales, marketing, the warehouse, accounting, customer service and IT. </div><div></div><div><img${ssrRenderAttr("src", _imports_6)}> Initial implementation of Pardot. Integrated a third party printing vendor with Salesforce so sales orders can automatically be sent and then drop-shipped to the customer. </div></div></div></div>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sample-projects.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sample-projects-2cc2c557.mjs.map
