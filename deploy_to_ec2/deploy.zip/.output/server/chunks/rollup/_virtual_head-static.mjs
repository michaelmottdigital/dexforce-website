const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"https://assets.calendly.com/assets/external/widget.css\">\n<script type=\"text/javascript\" async=\"\" src=\"https://assets.calendly.com/assets/external/widget.js\"></script>","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
