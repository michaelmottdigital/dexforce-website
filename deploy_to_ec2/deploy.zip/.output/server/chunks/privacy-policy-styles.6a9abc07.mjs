const privacyPolicy_vue_vue_type_style_index_0_scoped_5fde568a_lang = "p[data-v-5fde568a]{margin-bottom:1em}li[data-v-5fde568a]{list-style-type:circle;margin-left:1em}h2[data-v-5fde568a],h3[data-v-5fde568a]{margin-bottom:.5em;margin-top:.7em}";

const privacyPolicyStyles_6a9abc07 = [privacyPolicy_vue_vue_type_style_index_0_scoped_5fde568a_lang];

export { privacyPolicyStyles_6a9abc07 as default };
//# sourceMappingURL=privacy-policy-styles.6a9abc07.mjs.map
