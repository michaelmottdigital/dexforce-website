const nonprofitQuickstart_vue_vue_type_style_index_0_lang = "li{margin-top:1.25rem}";

const nonprofitQuickstartStyles_c14e41fa = [nonprofitQuickstart_vue_vue_type_style_index_0_lang];

export { nonprofitQuickstartStyles_c14e41fa as default };
//# sourceMappingURL=nonprofit-quickstart-styles.c14e41fa.mjs.map
