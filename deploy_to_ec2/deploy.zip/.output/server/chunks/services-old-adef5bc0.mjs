import { _ as __nuxt_component_0 } from './Header-e358a8a8.mjs';
import { _ as __nuxt_component_1 } from './SectionHeading-470cc8e2.mjs';
import { _ as __nuxt_component_2 } from './ServiceCard-50bc2383.mjs';
import { _ as __nuxt_component_1$1 } from './Footer-89a7582a.mjs';
import { withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './server.mjs';
import './nuxt-link-5d0b373b.mjs';
import 'ufo';
import './renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'defu';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Header = __nuxt_component_0;
  const _component_SectionHeading = __nuxt_component_1;
  const _component_ServiceCard = __nuxt_component_2;
  const _component_Footer = __nuxt_component_1$1;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Header, null, null, _parent));
  _push(`<div class="flex justify-center mt-20"><div class="w-4/5"><div class="w-2/6">`);
  _push(ssrRenderComponent(_component_SectionHeading, {
    superHeading: "this is the super heading",
    line1: "Our",
    line2: "Services",
    hideSuperHeading: ""
  }, null, _parent));
  _push(` Our consulting services are designed to provide end-to-end Salesforce support to small and medium sized businesses. </div><div class="flex flex-wrap gap-7 mt-20">`);
  _push(ssrRenderComponent(_component_ServiceCard, null, {
    title: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` On Going Support `);
      } else {
        return [
          createTextVNode(" On Going Support ")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` We provide ongoing support to businesses, ensuring that their Salesforce platform is always up-to-date and running smoothly. Our consultants are available to answer questions, troubleshoot issues, and provide training and guidance to your team. `);
      } else {
        return [
          createTextVNode(" We provide ongoing support to businesses, ensuring that their Salesforce platform is always up-to-date and running smoothly. Our consultants are available to answer questions, troubleshoot issues, and provide training and guidance to your team. ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ServiceCard, null, {
    title: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Non Profit Quick Start `);
      } else {
        return [
          createTextVNode(" Non Profit Quick Start ")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` We help businesses customize their Salesforce platform to meet their unique requirements. Our consultants will work with your team to ensure that Salesforce is tailored to meet your specific business processes and workflows. `);
      } else {
        return [
          createTextVNode(" We help businesses customize their Salesforce platform to meet their unique requirements. Our consultants will work with your team to ensure that Salesforce is tailored to meet your specific business processes and workflows. ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ServiceCard, null, {
    title: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Sales Cloud Quick Start `);
      } else {
        return [
          createTextVNode(" Sales Cloud Quick Start ")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Salesforce Sales Cloud Quick Start is an ideal solution for small and mid-sized businesses looking to quickly implement a powerful and scalable sales platform. With our expert guidance you can get up and running on Sales Cloud in a matter of weeks, rather than months. `);
      } else {
        return [
          createTextVNode(" Salesforce Sales Cloud Quick Start is an ideal solution for small and mid-sized businesses looking to quickly implement a powerful and scalable sales platform. With our expert guidance you can get up and running on Sales Cloud in a matter of weeks, rather than months. ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ServiceCard, null, {
    title: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Service Cloud Quick Start `);
      } else {
        return [
          createTextVNode(" Service Cloud Quick Start ")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Salesforce Service Cloud Quick Start is a service designed to help businesses rapidly implement Salesforce&#39;s Service Cloud platform. This service provides a streamlined approach to setting up and customizing Sales Cloud, enabling businesses to start using the platform quickly and efficiently. `);
      } else {
        return [
          createTextVNode(" Salesforce Service Cloud Quick Start is a service designed to help businesses rapidly implement Salesforce's Service Cloud platform. This service provides a streamlined approach to setting up and customizing Sales Cloud, enabling businesses to start using the platform quickly and efficiently. ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div>`);
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/services-old.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const servicesOld = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { servicesOld as default };
//# sourceMappingURL=services-old-adef5bc0.mjs.map
