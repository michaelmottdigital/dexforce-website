import{a as e,b as s,o as t}from"./entry.8549a200.js";const c={},o={class:"font-pt-serif"};function n(r,a){return t(),s("div",o)}const f=e(c,[["render",n]]);export{f as default};
